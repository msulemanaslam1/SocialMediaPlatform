package Controller;

import Model.Database;
import Model.Graph;
import View.Alert;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class RecommendedFriend {
    Graph graph;
    Database database;
    public RecommendedFriend() {
       graph = new Graph();
      database = new Database();

    }


    public String getUsernameById(int friendId){
        String sql = "select FirstName from users where id = "+friendId;
        try{
            ResultSet rs = database.getStatement().executeQuery(sql);
            if(rs.next()){
                return rs.getString("FirstName");
            }
        } catch (SQLException e){
            new Alert(e.getMessage(),null);
        }
        return null;
    }

    public List<Integer> getFriendsOfFriends(int userId) {
        Set<Integer> visited = new HashSet<>();
        Set<Integer> directFriends = new HashSet<>(graph.getGraph().getOrDefault(userId, Collections.emptySet()));
        Set<Integer> friendsOfFriends = new HashSet<>();

        Queue<Integer> queue = new LinkedList<>();
        queue.add(userId);
        visited.add(userId);

        while (!queue.isEmpty()) {
            int current = queue.poll();

            for (int neighbor : graph.getGraph().getOrDefault(current, Collections.emptySet())) {
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    queue.add(neighbor);

                    // Only add non-direct friends to the suggestion list
                    if (!directFriends.contains(neighbor) && neighbor != userId) {
                        friendsOfFriends.add(neighbor);
                    }
                }
            }
        }

        return friendsOfFriends.isEmpty() ? Collections.emptyList() : new ArrayList<>(friendsOfFriends);
    }

    public List<String> getFriendsOfFriends(List<Integer> list){
        Database database = new Database();
        List<String> friendsOfFriends = new ArrayList<>();
        for (Integer friendId : list) {
            String username = getUsernameById(friendId);
            friendsOfFriends.add(username);
        }
        return friendsOfFriends;
    }

    public static void main(String[] args) {
        RecommendedFriend recommendedFriend = new RecommendedFriend();
        List<Integer> friendsOfFriends = recommendedFriend.getFriendsOfFriends(2);
        System.out.println(friendsOfFriends);
    }
}
