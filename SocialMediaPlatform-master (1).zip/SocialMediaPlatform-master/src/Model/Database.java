package Model;

import View.Alert;

import javax.xml.crypto.Data;
import java.sql.*;

public class Database {
    private String user = "suleman";
    private String pass = "123456";
    private String url = "jdbc:mysql://localhost:3306/socialmedia";
    private Statement statement;

    private static final String URL = "jdbc:mariadb://localhost:3306/socialmedia";
//    private static final String USER = "test_user";
//    private static final String PASSWORD = "your_password";
//    private static Connection connection;
//    private Statement statement;

    public Database(){
        try{
            Connection connection = DriverManager.getConnection(url, user, pass);
            statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
        } catch (SQLException e){
            new Alert(e.getMessage(), null);
        }
    }
//    public Statement getStatement() throws SQLException {
//        statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
//        return statement;
//    }

//    public Database(){
//       if (connection == null) {
//            try {
//                connection = DriverManager.getConnection(URL, USER, PASSWORD);
//                statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
//            } catch (SQLException e) {
//                System.err.println("Connection failed: " + e.getMessage());
//            }
//        }
//    }


}
