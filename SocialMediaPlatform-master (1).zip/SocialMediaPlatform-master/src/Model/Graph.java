package Model;

import View.Alert;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class Graph {

    public static HashMap<Integer, Set<Integer>> graph = new HashMap<>();
    Database database;

    public Graph() {
        database = new Database();
        loadGraph2();
        System.out.println(graph.toString());

    }

    public HashMap<Integer,Set<Integer>> getGraph(){
        return graph;
    }


    public void addUser(int userId) {
        graph.putIfAbsent(userId, new HashSet<>());
    }

    public void addFriend(int userId, int friendId) {
        addUser(userId);
        addUser(friendId);
        graph.get(userId).add(friendId);
        graph.get(friendId).add(userId);
    }


    public static void printGraph() {
        for (int i : graph.keySet()) {
            System.out.print(i + " -> ");
            for (int j : graph.get(i)) {
                System.out.print(j + " ");
            }
            System.out.println();
        }
    }

    public Set<Integer> getFriends(int userId) {
        return graph.getOrDefault(userId, new HashSet<>());
    }


    void loadGraph()  {
        ArrayList<Integer> users = new ArrayList<>();
        String sql = "select ID from users";
        try{
            ResultSet rs = database.getStatement().executeQuery(sql);
            while(rs.next()){
                users.add(rs.getInt("ID"));
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    void loadGraph2(){
        String sql = "Select * from friends";
        try{
            ResultSet rs = database.getStatement().executeQuery(sql);
            while(rs.next()){
                int user1= rs.getInt("User");
                int user2=rs.getInt("Friend");
                 graph.computeIfAbsent(user1, k -> new HashSet<>()).add(user2);
                 graph.computeIfAbsent(user2, k -> new HashSet<>()).add(user1);

            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    public List<String> getMutualFriends(int user1, int user2)  {
        // friend of user 1
        Set<Integer> friendsOfUser1 =getFriends(user1);
        System.out.println(friendsOfUser1 +" are friends of 1");
        // friend of user 2
        Set<Integer> friendsOfUser2 = getFriends(user2);
        System.out.println(friendsOfUser2+ "are friends of 2");
        // intersection
        friendsOfUser1.retainAll(friendsOfUser2);

        List<String> mutualFriends = new ArrayList<>();
        for (Integer friendId : friendsOfUser1) {
            String username = getUsernameById(friendId);
            mutualFriends.add(username);
        }

        return mutualFriends;
    }

    public String getUsernameById(int friendId){
        String sql = "select FirstName from users where id = "+friendId;
        try{
            ResultSet rs = database.getStatement().executeQuery(sql);
            if(rs.next()){
                return rs.getString("FirstName");
            }
        } catch (SQLException e){
            new Alert(e.getMessage(),null);
        }
        return null;
    }


    public static void main(String[] args) {
        Graph g = new Graph();
    }

    // 1 -> 2 3 4 5 6
    //2 -> 1 3 5 6
    //3 -> 1 2 5
    //4 -> 1 5 7
    //5 -> 1 2 3 4
    //6 -> 1 2 7
    //7 -> 4 6
}
